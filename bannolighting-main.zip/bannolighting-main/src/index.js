import './index.html'
import './index.scss'

$(document).ready(function () {
  //mobile menu
  $('.hamburger').click(function () {
    var check = $('.hamburger').hasClass('is-active')
    if (!check) {
      $('.hamburger').addClass('is-active')
      $('header').addClass('active')
    } else {
      $('.hamburger').removeClass('is-active')
      $('header').removeClass('active')
    }
  })
  // Reviews Carousel in main page
  var owl = $('.owl-carousel')
  owl.owlCarousel({
    stagePadding: 200,
    loop: false,
    margin: 20,
    nav: false,
    items: 3,
    dots: false,
    responsive: {
      0: {
        items: 1,
        stagePadding: 2,
      },
      567: {
        items: 2,
        stagePadding: 20,
      },
      1180: {
        items: 2,
      },
    },
  })
})
